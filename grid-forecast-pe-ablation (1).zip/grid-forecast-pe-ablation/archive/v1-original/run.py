"""Cobalt Grid positional-encoding ablation. One command runs everything:
    python run.py --config config.yaml
Outputs go to results/: runs.csv, summary.csv, summary.md, mae_by_setting.png, example_forecast.png, environment.json
"""
import argparse, json, math, os, platform, random, time
import numpy as np, pandas as pd, torch, torch.nn as nn, yaml
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

def set_seed(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s); torch.cuda.manual_seed_all(s)

# ---------- 1. Data: synthetic hourly demand for one rural co-op ----------
def make_demand(days, seed):
    rng = np.random.default_rng(seed)
    h = np.arange(days * 24); hour, day = h % 24, h // 24
    daily = 1.0 + 0.35 * np.exp(-((hour - 8) ** 2) / 6) + 0.55 * np.exp(-((hour - 19) ** 2) / 8)  # morning + evening peaks
    weekly = np.where(day % 7 >= 5, 0.85, 1.0)                                                     # weekends lower
    temp = 10 - 12 * np.cos(2 * np.pi * day / 365) + rng.normal(0, 3, len(h))                      # deg C, cold winters
    heating, cooling = np.clip(15 - temp, 0, None) * 0.03, np.clip(temp - 22, 0, None) * 0.04
    demand_mw = 5.0 * daily * weekly * (1 + heating + cooling) + rng.normal(0, 0.25, len(h))
    return pd.DataFrame({"hour_index": h, "demand_mw": demand_mw.round(3)})

def windows(series, lookback, horizon):
    X = np.lib.stride_tricks.sliding_window_view(series, lookback + horizon)
    return torch.tensor(X[:, :lookback], dtype=torch.float32), torch.tensor(X[:, lookback:], dtype=torch.float32)

# ---------- 2. Model: tiny transformer; ONLY the positional encoding changes ----------
class Forecaster(nn.Module):
    def __init__(self, pe, lookback, horizon, d_model, layers, heads):
        super().__init__()
        self.pe = pe
        self.inp = nn.Linear(1, d_model)
        if pe == "learned":
            self.pos = nn.Parameter(torch.randn(lookback, d_model) * 0.02)
        elif pe == "sinusoidal":
            pos, i = torch.arange(lookback)[:, None], torch.arange(0, d_model, 2)
            table = torch.zeros(lookback, d_model)
            table[:, 0::2] = torch.sin(pos / 10000 ** (i / d_model)); table[:, 1::2] = torch.cos(pos / 10000 ** (i / d_model))
            self.register_buffer("pos", table)
        layer = nn.TransformerEncoderLayer(d_model, heads, 4 * d_model, dropout=0.0, batch_first=True)
        self.enc = nn.TransformerEncoder(layer, layers)
        self.head = nn.Linear(d_model, horizon)
    def forward(self, x):                       # x: (batch, lookback) normalized demand
        h = self.inp(x[..., None])
        if self.pe != "none": h = h + self.pos  # "none": the model does not know which hour is which
        return self.head(self.enc(h).mean(1))   # average over hours, then predict 24 values

# ---------- 3. One training run = one (setting, seed) ----------
def run_one(setting, seed, cfg, data):
    set_seed(seed)
    m = cfg["model"]; model = Forecaster(setting, m["lookback"], m["horizon"], m["d_model"], m["layers"], m["heads"]).to(DEVICE)
    opt = torch.optim.Adam(model.parameters(), cfg["train"]["lr"])
    Xtr, Ytr, Xte, Yte, mu, sd = data
    if DEVICE == "cuda": torch.cuda.reset_peak_memory_stats(); torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(cfg["train"]["epochs"]):
        for idx in torch.randperm(len(Xtr)).split(cfg["train"]["batch_size"]):
            loss = nn.functional.mse_loss(model(Xtr[idx].to(DEVICE)), Ytr[idx].to(DEVICE))
            opt.zero_grad(); loss.backward(); opt.step()
    if DEVICE == "cuda": torch.cuda.synchronize()
    train_s = time.perf_counter() - t0
    model.eval()
    with torch.no_grad():
        pred = torch.cat([model(Xte[i:i + 512].to(DEVICE)).cpu() for i in range(0, len(Xte), 512)])
        mae_mw = float((pred - Yte).abs().mean() * sd)                      # back to megawatts
        times = []                                                           # latency: one forecast at a time
        x1 = Xte[:1].to(DEVICE)
        for k in range(cfg["latency"]["warmup"] + cfg["latency"]["trials"]):
            if DEVICE == "cuda": torch.cuda.synchronize()
            t = time.perf_counter(); model(x1)
            if DEVICE == "cuda": torch.cuda.synchronize()
            if k >= cfg["latency"]["warmup"]: times.append((time.perf_counter() - t) * 1000)
    peak_mb = torch.cuda.max_memory_allocated() / 2 ** 20 if DEVICE == "cuda" else float("nan")
    return {"setting": setting, "seed": seed, "test_mae_mw": round(mae_mw, 4), "train_s": round(train_s, 1),
            "p50_ms": round(float(np.percentile(times, 50)), 3), "p95_ms": round(float(np.percentile(times, 95)), 3),
            "peak_mem_mb": round(peak_mb, 1), "params": sum(p.numel() for p in model.parameters() if p.requires_grad)}, model, pred

# ---------- 4. Main: data -> 9 runs -> tables, plots, environment ----------
def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--config", default="config.yaml"); args = ap.parse_args()
    cfg = yaml.safe_load(open(args.config)); os.makedirs("results", exist_ok=True); os.makedirs("data", exist_ok=True)

    df = make_demand(cfg["data"]["days"], cfg["data"]["data_seed"]); df.to_csv("data/demand.csv", index=False)
    split = int(len(df) * (1 - cfg["data"]["test_share"]))
    train_s, test_s = df.demand_mw.values[:split], df.demand_mw.values[split - cfg["model"]["lookback"]:]
    mu, sd = train_s.mean(), train_s.std()                                   # normalize with TRAIN statistics only
    Xtr, Ytr = windows((train_s - mu) / sd, cfg["model"]["lookback"], cfg["model"]["horizon"])
    Xtr, Ytr = Xtr[::cfg["data"]["train_stride"]], Ytr[::cfg["data"]["train_stride"]]
    Xte, Yte = windows((test_s - mu) / sd, cfg["model"]["lookback"], cfg["model"]["horizon"])
    print(f"device {DEVICE} | {len(df)} hours | train windows {len(Xtr)} | test windows {len(Xte)}")
    data = (Xtr, Ytr, Xte, Yte, mu, sd)

    rows, example = [], {}
    for setting in cfg["ablation"]["settings"]:
        for seed in cfg["ablation"]["seeds"]:
            r, model, pred = run_one(setting, seed, cfg, data); rows.append(r)
            if seed == cfg["ablation"]["seeds"][0]: example[setting] = pred[-1].numpy() * sd + mu
            print(f"{setting:10s} seed {seed}: MAE {r['test_mae_mw']:.3f} MW | train {r['train_s']} s | "
                  f"p50 {r['p50_ms']} ms p95 {r['p95_ms']} ms | peak {r['peak_mem_mb']} MB")
    runs = pd.DataFrame(rows); runs.to_csv("results/runs.csv", index=False)

    g = runs.groupby("setting", sort=False)
    summary = pd.DataFrame({"mae_mean": g.test_mae_mw.mean(), "mae_std": g.test_mae_mw.std(), "mae_min": g.test_mae_mw.min(),
                            "mae_max": g.test_mae_mw.max(), "p50_ms": g.p50_ms.median(), "p95_ms": g.p95_ms.median(),
                            "peak_mem_mb": g.peak_mem_mb.max(), "train_s": g.train_s.mean(), "params": g.params.first()})
    # 95% confidence interval of each mean (t-distribution, n = number of seeds; t values from standard tables)
    T95 = {2: 12.706, 3: 4.303, 4: 3.182, 5: 2.776, 6: 2.571, 7: 2.447, 8: 2.365, 9: 2.306, 10: 2.262}
    n = len(cfg["ablation"]["seeds"]); half = T95.get(n, 1.96) * summary.mae_std / math.sqrt(n)
    summary.insert(2, "ci95_low", summary.mae_mean - half); summary.insert(3, "ci95_high", summary.mae_mean + half)
    summary = summary.round(4); summary.to_csv("results/summary.csv")

    # Noise check: a difference counts as real only if the 95% CIs of the two means do NOT overlap.
    verdicts, names = [], list(summary.index)
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            a, b = summary.loc[names[i]], summary.loc[names[j]]
            separate = a.ci95_high < b.ci95_low or b.ci95_high < a.ci95_low
            verdicts.append(f"- {names[i]} vs {names[j]}: mean difference {abs(a.mae_mean - b.mae_mean):.3f} MW -> "
                            + ("EXCEEDS run-to-run noise (95% CIs do not overlap)" if separate
                               else "WITHIN run-to-run noise (95% CIs overlap): no difference can be claimed"))
    with open("results/summary.md", "w") as f:
        f.write("## Test MAE by positional-encoding setting (3 seeds each)\n\n" + "```\n" + summary.to_string() + "\n```" + "\n\n## Noise check\n\n" + "\n".join(verdicts) + "\n")
    print("\n", summary.to_string(), "\n\nNOISE CHECK\n" + "\n".join(verdicts))

    fig, ax = plt.subplots(figsize=(6, 4))
    for k, s in enumerate(names):
        ax.bar(k, summary.loc[s, "mae_mean"], color="#9bb7d4"); ax.scatter([k] * 3, runs[runs.setting == s].test_mae_mw, color="k", zorder=3)
    ax.set_xticks(range(len(names))); ax.set_xticklabels(names); ax.set_ylabel("test MAE (MW), lower is better")
    ax.set_title("Bar = mean of 3 seeds, dots = each seed"); plt.tight_layout(); plt.savefig("results/mae_by_setting.png", dpi=120)
    fig, ax = plt.subplots(figsize=(7, 3.5)); ax.plot(Yte[-1].numpy() * sd + mu, "k", lw=2, label="actual")
    for s in names: ax.plot(example[s], label=s)
    ax.set_xlabel("hour ahead"); ax.set_ylabel("demand (MW)"); ax.legend(); ax.set_title("Last test day: actual vs forecasts (seed 0)")
    plt.tight_layout(); plt.savefig("results/example_forecast.png", dpi=120)

    env = {"python": platform.python_version(), "torch": torch.__version__, "numpy": np.__version__, "pandas": pd.__version__,
           "device": torch.cuda.get_device_name(0) if DEVICE == "cuda" else "cpu", "config": cfg}
    json.dump(env, open("results/environment.json", "w"), indent=1)
    with open("results/requirements_used.txt", "w") as f:   # exact versions of THIS run, to pin in requirements.txt
        f.write(f"torch=={torch.__version__.split('+')[0]}\nnumpy=={np.__version__}\npandas=={pd.__version__}\n"
                f"matplotlib=={matplotlib.__version__}\npyyaml=={yaml.__version__}\n")
    print("\nsaved results/ (runs.csv, summary.csv, summary.md, 2 plots, environment.json, requirements_used.txt)")

if __name__ == "__main__":
    main()
