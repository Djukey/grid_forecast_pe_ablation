# Cobalt Grid: does positional encoding matter for 24-hour demand forecasts?

A controlled ablation for Cobalt Grid's short-horizon electricity-demand forecaster.

- **One question:** which positional-encoding setting should the forecaster use: `none`, `sinusoidal` (fixed sine/cosine) or `learned`?
- **One change only:** data, model size, training and evaluation are identical across runs. Only the positional encoding changes.
- **Short answer:** `sinusoidal` clearly beats `none`. `learned` is too unstable across seeds to be distinguished from either.

## How to reproduce (one command)

**Google Colab (reference environment):**

1. Runtime → Change runtime type → **T4 GPU**
2. Upload `cobalt-grid-pe-ablation.zip` and `Cobalt_colab.ipynb`
3. Open the notebook and use **Runtime → Run all** (about 2 minutes)

**Any machine with Python 3.10+:**

```bash
pip install -r requirements.txt
python run.py --config config.yaml
```

All outputs are written to `results/`. The run order is fixed inside `run.py`: data → split → 9 training runs → evaluation → summary, plots and environment record. Nothing has to be run by hand in between.

## What the script does

1. **Generates the data** (`data/demand.csv`): two years (17,520 hours) of synthetic hourly demand for one rural co-op. It includes morning and evening peaks, lower weekends, winter heating and summer cooling driven by a synthetic temperature, and random noise. Fixed `data_seed: 42`. No real customer data.
2. **Splits by time:** the first 80% is used for training and the last 20% for testing, so the model always predicts the future from the past. Normalization uses training statistics only.
3. **Trains a small transformer** (2 layers, width 32, 4 heads) that reads the past 168 hours and predicts the next 24.
4. **Runs the ablation:** 3 settings × 3 seeds = 9 runs. Each run records:
   - test MAE in MW (mean absolute error; lower is better)
   - training time
   - latency p50 and p95 for one forecast (20 warm-up calls, 200 timed calls, GPU synchronized)
   - peak GPU memory
   - trainable parameters
5. **Checks noise:** a difference counts as real only if the **95% confidence intervals** of the two means do not overlap (t-distribution, 3 seeds). A first analysis used the looser rule "seed ranges do not overlap", which called all three differences real; the stricter rule is reported, and the change is disclosed in the technical documentation.

## Control decisions (what is held fixed, and why)

| Held fixed | Why |
|---|---|
| Same data, same `data_seed` for every run | Any difference must come from the model, not the data |
| Same time-based split and the same test windows | Every setting takes the same exam |
| Same seeds (0, 1, 2) in every setting | Every run can be repeated exactly, and each setting gets the same number of independent random starts |
| Same architecture, width, layers and heads | Only the positional encoding differs |
| Same optimizer, learning rate, batch size, 10 epochs, no early stopping | Tuning each setting separately would add a second variable |
| Same training stride (every 4th window) | Every setting sees the same training examples |
| Same evaluation code and latency procedure | Measurements are comparable |

**The one difference that is part of the factor itself:** `learned` has 5,376 more trainable parameters (31,640 vs 26,264). Those parameters **are** the learned position table (168 positions × 32 dimensions), so they're part of the setting being tested, not a separate change. It's reported so readers can judge it.

## Files

| File | Purpose |
|---|---|
| `run.py` | The single seeded, config-driven entry point |
| `config.yaml` | Every setting: data size, model size, epochs, the 3 settings, the 3 seeds. Change this, not the code. |
| `requirements.txt` | Library versions pinned to the reference Colab run |
| `Cobalt_colab.ipynb` | Runs the package in Google Colab |
| `results/runs.csv` | One row per run (9 rows) |
| `results/summary.csv`, `results/summary.md` | Mean, standard deviation, 95% CI, min and max per setting, plus the noise check |
| `results/mae_by_setting.png` | Bars = mean of 3 seeds, dots = individual seeds |
| `results/example_forecast.png` | Actual vs forecast for the last test day |
| `results/environment.json`, `results/requirements_used.txt` | Exact Python version, library versions and GPU of the run |

## Reference results (Colab, Tesla T4)

| Setting | MAE mean (MW) | 95% CI (MW) | Seed range (MW) | p50 / p95 latency (ms) | Peak GPU memory (MB) | Parameters |
|---|---|---|---|---|---|---|
| none | 1.010 | 1.006–1.014 | 1.009–1.012 | 0.76 / 1.09 | 110.0 | 26,264 |
| **sinusoidal** | **0.602** | **0.536–0.669** | 0.574–0.627 | 0.77 / 0.95 | 110.1 | 26,264 |
| learned | 0.817 | 0.430–1.205 | 0.719–0.997 | 0.76 / 0.88 | 110.1 | 31,640 |

Latency is the median across the 3 seeds. Between two separate Colab sessions, the test MAE values were identical, while latency moved by about 0.1–0.3 ms. Latency differences between settings are therefore noise.

**Noise check:**

- **sinusoidal vs none:** exceeds noise. A 0.408 MW (40%) lower error, and the intervals are far apart.
- **learned vs none** and **learned vs sinusoidal:** **within noise.** The learned seeds spread so widely (0.72 to 1.00 MW) that its interval overlaps both other settings. No claim can be made about `learned`.

**Cost:** latency, memory and training time are practically identical across settings, so the choice rests on accuracy and stability.

**Reproducibility check:** the same config produced identical MAE values on a CPU-only machine and on the Colab T4.

## What this study cannot conclude

- **Synthetic data only.** It doesn't show performance on real co-op demand, holidays, outages or extreme weather.
- **3 seeds per setting is small.** Enough to confirm the large sinusoidal-vs-none gap; not enough to rank `learned`.
- **One configuration:** one model size, one 7-day window, one 24-hour horizon, one co-op, 10 epochs, one learning rate.
- **No simple baseline** (such as "same hour last week") is compared.
- **Latency was measured on a Colab T4**, not on production hardware.
