# Reproducibility audit of the v1 package

This audit covers the first version of this study (a 9-run positional-encoding ablation, 3 settings × 3 seeds). It lists what an outside reader **could not** reproduce or verify from v1, and what v2 changed. It is based on the v1 files, which are preserved unchanged in `archive/v1-original/`.

## What a stranger could not reproduce from v1

| # | Gap in v1 | Why it blocks a stranger | v2 fix |
|---|---|---|---|
| 1 | **Hardware recorded as a device name only.** No VRAM, driver, CUDA runtime, cuDNN, compute capability. | Timing and memory numbers cannot be compared with another machine. | `run.py` logs all of these automatically to `results/environment.json` and writes a one-line footnote used under every table and figure. |
| 2 | **Precision, batch sizes, sequence length and wall-clock were not recorded** (they existed only in `config.yaml`, not in the results). | A reader cannot tell what workload produced the numbers. | The `workload` block of `environment.json` records them; total wall-clock is logged. |
| 3 | **`results/` shipped empty.** The reference numbers were typed into the README by hand. | Nothing to check the README against; numbers were not traceable to measurements. | Raw measurements are committed (`results/runs.csv`); the README table is copied from `results/summary.csv`. |
| 4 | **Latency came from one pass per run**, reported as a median over seeds with no spread. | One busy moment on a shared GPU could distort it, and nothing showed how much. | The whole study is re-executed 3 times (`repeats: 3`). Timing is reported as mean ± SD across repeats. |
| 5 | **"Identical across sessions" was observed, not built in.** | A reader had to trust it. | Repeats use the same seeds; `checks.json` stores the largest MAE difference between repeats. |
| 6 | **No simple baseline.** | "Sinusoidal is best of the three" had no reference point for whether it is any good. | Added "same hour last week" as a reference. It scores about 0.56 MW, which changes the conclusion (see README). |
| 7 | **Figures were drawn from in-memory variables.** | A reader could not redraw or inspect the plotted numbers. | Figures are drawn only from the CSV/JSON files; `python run.py --figures-only` redraws them without a GPU. |
| 8 | **Environment pinned only to the Colab versions, with no check.** Python version and OS unrecorded. | `pip install` could silently give different versions. | The Colab notebook compares installed versions with `requirements.txt` and prints any mismatch; Python and OS are recorded. |
| 9 | **No fast pipeline check, no data checksum, no licence.** Paths depended on the working directory. | A reviewer could not verify the pipeline in a minute or confirm the data matched. | `config_smoke.yaml`, SHA-256 of the generated data in `checks.json`, MIT licence, paths resolved from the script location. |
| 10 | **Reads as a course exercise.** Notebook and README were framed around an assignment. | Not legible as professional work. | Rewritten README for an audit reader; coursework wording removed. |

## Threats that v2 reduces but does not remove

- Only 3 seeds per setting. The confidence intervals are wide; this is a limit of the budget, not something repeats fix (repeats re-run the same seeds, so they test determinism and timing, not seed variation).
- The data is synthetic.
- One model size, one horizon and one learning rate.

These are stated again, with the direction of likely error, in the README's Limitations section.

## How the re-measurement was done

1. Clean environment from `requirements.txt` on a Colab T4.
2. `python run.py`, with fixed seeds 0, 1, 2 in every setting.
3. The full study (9 training runs) executed 3 times end to end.
4. Accuracy statistics use repeat 0 only, because the seeds are the independent samples. Pooling the repeats would pretend to a sample size of 27.
5. Timing statistics use all three repeats.
